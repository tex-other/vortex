
/*
 * @(#)eval.h 2.5 EPA
 *
 * Copyright 1987,1988 Pat J Monardo
 *
 * Redistribution of this file is permitted through
 * the specifications in the file COPYING.
 *
 * 
 */

int     main_control();
int     app_space();
int     insert_dollar_sign();
int     you_cant();
int     report_illegal_case();
bool    privileged();
int     missing_font();
bool    its_all_over();
